# @cloudia/sdk

Client, browser tracker, Next.js cache helpers, React component, and type generator for CloudIA CMS. No runtime dependencies; React is an optional peer for `@cloudia/sdk/react`.

```bash
npm i @cloudia/sdk
# or while developing locally
npm i file:../cloudia-cms/sdk
```

Build from source with `npm run build` in this folder (or `npm run sdk:build` at the repository root); output lands in `dist/`.

## Entry points

| Import                 | Contents                                                                                             |
| ---------------------- | ---------------------------------------------------------------------------------------------------- |
| `@cloudia/sdk`         | `createCloudiaClient`, `createCloudiaTracker`, `generateTypes`, types                                |
| `@cloudia/sdk/client`  | `createCloudiaClient(config)` with `list`, `listAll`, `one`, `single`, `schema`, `mediaUrl`          |
| `@cloudia/sdk/tracker` | `createCloudiaTracker(config)` with `start`, `stop`, `pageChanged`, `track`                          |
| `@cloudia/sdk/auto`    | Self-starting tracker for a `<script type="module">`, configured from its URL; sets `window.cloudia` |
| `@cloudia/sdk/next`    | `createNextCloudiaClient`, `cloudiaTags`, `createRevalidateHandler`, `verifyCloudiaSignature`        |
| `@cloudia/sdk/react`   | `<CloudiaAnalytics />`, `useCloudiaTracker()`                                                        |
| `@cloudia/sdk/typegen` | `generateTypes(schema, { depth })`                                                                   |

## CLI

```bash
npx cloudia types  --url https://cms.example.com --site partsmall --key cld_read_… --out src/cloudia.types.ts [--depth 1]
npx cloudia schema --url … --site … --key …
npx cloudia import --url … --site … --cookie <cloudia_session> --collection <id> --file entries.json [--publish]
```

Flags fall back to `CLOUDIA_URL`, `CLOUDIA_SITE`, and `CLOUDIA_READ_KEY`.

## Client

```ts
import { createCloudiaClient } from '@cloudia/sdk'
const cms = createCloudiaClient({
  baseUrl: 'https://cms.example.com',
  site: 'partsmall',
  readKey: process.env.CLOUDIA_READ_KEY!,
})

const { items, total, hasMore } = await cms.list<Branch>('branches', {
  where: { active: true, province: { in: ['gauteng', 'limpopo'] }, name: { contains: 'mall' } },
  sort: 'name',
  depth: 1,
  fields: ['name', 'slug', 'photo'],
  page: 1,
  limit: 50,
})
const all = await cms.listAll<Branch>('branches')
const one = await cms.one<Branch>('branches', 'meadowdale') // null on 404
const settings = await cms.single<Settings>('site-settings') // null when unpublished
```

Errors throw `CloudiaError` with `status` and `url`.

## Next.js

`createNextCloudiaClient` adds `next: { revalidate, tags }` to every request so the revalidation route can purge exactly what changed. See `docs/INTEGRATION.md` in the CMS repository for the full setup, including the webhook route and the analytics component.

## Tracker

```ts
import { createCloudiaTracker } from '@cloudia/sdk/tracker'
const tracker = createCloudiaTracker({
  baseUrl,
  site,
  ingestKey,
  autoStart: false,
  respectDoNotTrack: true,
})
tracker.start() // after consent
tracker.track('form_submit', { form: 'enquiry' })
```

Automatic `page_view` on start and route change, `page_exit` with duration on hide/unload, per-tab session ids in `sessionStorage`, no cookies.

Clicks on elements with `data-cloudia-event="type"` (and submits of forms with it) send that event with every inherited `data-cloudia-*` attribute as metadata; WhatsApp, `tel:` and `mailto:` links send `contact_click`. Pass `endpoint` instead of `baseUrl` and `site` to post to a keyless route such as a Payload-compatible `/api/analytics-events`. See `docs/INTEGRATION.md`.

## Payload export

`examples/export-from-payload.ts` runs inside a Payload 3 project and writes CloudIA import files for every collection and global, converting Lexical rich text to Markdown. See `docs/PAYLOAD-TO-CLOUDIA.md`.
